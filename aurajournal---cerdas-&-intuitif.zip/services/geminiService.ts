
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function generateReflection(content: string, mood: string) {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Jurnal pengguna hari ini: "${content}". 
                Mood pengguna: ${mood}. 
                Berikan refleksi singkat, empati, dan satu saran kecil atau pertanyaan reflektif untuk besok dalam Bahasa Indonesia yang hangat.`,
      config: {
        temperature: 0.7,
        topP: 0.8,
        topK: 40,
      }
    });

    return response.text;
  } catch (error) {
    console.error("Gemini Reflection Error:", error);
    return "Maaf, AI sedang beristirahat sejenak. Tetap semangat!";
  }
}

export async function getInsights(entries: string) {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Analisis kumpulan jurnal berikut dan berikan ringkasan tren emosi serta saran pertumbuhan diri: ${entries}`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            summary: { type: Type.STRING },
            dominantMood: { type: Type.STRING },
            growthTips: { type: Type.ARRAY, items: { type: Type.STRING } }
          },
          required: ["summary", "dominantMood", "growthTips"]
        }
      }
    });
    return JSON.parse(response.text);
  } catch (error) {
    console.error("Gemini Insights Error:", error);
    return null;
  }
}
